<h2>{{ $gateway['name'] }}</h2>

@if ($gateway['description'])
<div class="well well-sm">
    {{ $gateway['description'] }}
</div>
@endif
